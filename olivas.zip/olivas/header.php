<!doctype html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">

  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <nav class="burger-nav">
    <div class="burger-open"></div>
  </nav>
  <header class="header">
    <div class="header-close"><span class="header-close--icon"></span></div>
    <div class="header-container">
      <?php $logo = get_theme_mod('custom_logo');
      $image = wp_get_attachment_image_src($logo, 'full');
      if ($image) :
        $image_url = $image[0];
        echo '<a href="' . get_home_url() . '"><img src="' . $image_url . '" alt="Logo" class="header-logo" /></a>';
      endif; ?>


      <?php
      wp_nav_menu(
        array(
          'theme_location' => 'menu-1',
          'menu_id'        => 'primary-menu',
        )
      );
      ?>
    </div>
  </header>
  <div class="overlay"></div>