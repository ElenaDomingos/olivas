<?php
get_header();
?>
<div class="hero">
  <h1 class="hero--title">All Projects</h1>
</div>
<div class="container">

  <?php
  if (have_posts()) :
    echo do_shortcode('[filterableProjects]');
  else :
    echo '<p>Nothing here</p>';
  endif;
  ?>

</div>

<?php

get_footer();
