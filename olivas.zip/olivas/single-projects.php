<?php
get_header();
?>
<div class="single">
  <div class="container">
    <?php
    if (have_posts()) :
      while (have_posts()) :
        the_post();
        $terms = get_the_terms(get_the_ID(), 'tipo');
        $tax = '';
        foreach ($terms as $termin) {
          echo $termin->name;
          $tax = $termin->slug;
        }

        echo '<h1>' . get_the_title() . '</h1>';

        echo '<img src="' . get_the_post_thumbnail_url() . '" />';

        echo '<div class="single-content"><p>' . get_the_content() . '</p></div>';
        if (get_field('project_url')) :
          echo '<a href="' . get_field('project_url') . '" class="single-project-url">Go to project</a>';
        endif;
      endwhile;
    else :
      echo '<p>Nothing here </p>';
    endif;
    ?>
  </div>
  <div class="relation-projects">

    <div class="container">
      <h3>Related Projects</h3>
      <?php
      $posts = new WP_Query(array(
        'post_type' => 'projects',
        'orderby' => 'ID',
        'order' => 'DESC',
        'posts_per_page' => 2,
        'post__not_in' => array(get_the_ID()),
        'tax_query' => array(
          array(
            'taxonomy' => 'tipo',
            'field'    => 'name',
            'terms'    => array($tax),
          )

        ),

      ));
      echo '<ul class="project_list">';
      while ($posts->have_posts()) :
        $posts->the_post();
        $terms = get_the_terms(get_the_ID(), 'tipo');
        $taxon = '';
        foreach ($terms as $termin) {
          $taxon = $termin->slug . ' ';
        }
        echo '<li class="product__item ' . $taxon . '"><a href="' . get_the_permalink() . '"  >';
        echo '<div class="single-project">';
        echo '<img src="' . get_the_post_thumbnail_url() . '" alt="" class="single-project--image" />';
        echo '<h3>' . get_the_title() . '</h3>';
        echo '<p>' . get_the_excerpt() . '</p>';
        // Get terms

        echo '<div class="project-terms--list">';
        foreach ($terms as $termin) {
          echo '<p class="project-term">' . esc_html($termin->name) . '</p>';
        }
        echo '</div></div></a></li>';

      endwhile;
      wp_reset_query();
      ?>
    </div>
  </div>
</div>
<?php

get_footer();
