<?php
get_header();
?>
<div class="container">
  <h1 class="home-title">Bem-vindo ao Olivas Digital</h1>
  <p class="home-desc">Um serviço de alta qualidade. Temos melhores profissionais.</p>

  <?php
  $posts = new WP_Query(array(
    'post_type' => 'projects',
    'post_per_page' => -1

  ));
  echo '<ul class="project_list">';
  while ($posts->have_posts()) :
    $posts->the_post();
    $terms = get_the_terms(get_the_ID(), 'tipo');
    $taxon = '';
    foreach ($terms as $termin) {
      $taxon = $termin->slug . ' ';
    }
    echo '<li class="product__item ' . $taxon . '"><a href="' . get_the_permalink() . '"  >';
    echo '<div class="single-project">';
    echo '<img src="' . get_the_post_thumbnail_url() . '" alt="" class="single-project--image" />';
    echo '<h3>' . get_the_title() . '</h3>';
    echo '<p>' . get_the_excerpt() . '</p>';
    // Get terms

    echo '<div class="project-terms--list">';
    foreach ($terms as $termin) {
      echo '<p class="project-term">' . esc_html($termin->name) . '</p>';
    }
    echo '</div></div></a></li>';

  endwhile;
  wp_reset_query();
  ?>
  </ul>
</div>

<?php
get_footer();
