<?php
get_header();
?>
<div class="hero">
  <h1 class="hero--title"><?php echo the_title(); ?></h1>
</div>
<div class="container">

  <?php
  while (have_posts()) :
    the_post();

    the_content();

  endwhile;
  ?>
</div>


<?php

get_footer();
