jQuery(document).ready(function($) {
  $('.burger-nav').on('click', function(){
     $('.header').css('transform', 'translate(0)');
     $('.overlay').css('display', 'block');
  });

  $('.header-close').on('click', function(){
    $('.header').css('transform', 'translate(-100%)');
    $('.overlay').css('display', 'none');
  });
});


(function() {
 
  const elem = document.querySelector('.project_list');
  const iso = new Isotope(elem, {

  itemSelector: '.product__item',
  filter: '.product__item'
});

  const controlls = document.querySelectorAll(".filter__link");
  const activeClass = "filter__item--active";
  controlls.forEach(function(control) {

    control.addEventListener("click", function(e) {
      e.preventDefault();

      const filterName = control.getAttribute("data-filter");

      controlls.forEach(function(link) {
        link.closest(".filter__item").classList.remove(activeClass);
      })
      control.closest(".filter__item").classList.add(activeClass);

      iso.arrange({
        filter: `.${filterName}`
      })
    })
  })

  
})();
