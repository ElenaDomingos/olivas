<?php
get_header();
?>
<div class="container">

  <h3>Oops, this page is not exist.</h3>
  <a href="<?php echo get_home_url(); ?>" class="btn">Go to home page</a>

</div>
<?php

get_footer();
