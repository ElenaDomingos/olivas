=== Olivas ===
Contributors: elenadom
Donate link: https://www.paypal.com/donate/?hosted_button_id=F48W6YHHKZ7FN
Tags: Custom Theme, MVP
Requires at least: 6.0
Tested up to: 6.0
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 
How to use this theme?

Install the main folder olivas.zip
Install all the required plugins
Import XML file
Go to Configurações -> Links permanentes and choose the estrutura Nome do post, then save configurations
#   o l i v a s  
 